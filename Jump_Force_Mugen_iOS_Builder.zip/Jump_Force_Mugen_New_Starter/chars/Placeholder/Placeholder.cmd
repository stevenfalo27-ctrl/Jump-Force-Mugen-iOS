; Placeholder command scaffold. Real command/state files must be supplied for playable characters.
[Command]
name = "recovery"
command = ~D, DF, F, a
time = 15

# Jump Force Mugen — iOS Builder

This package combines the custom 1,600-slot roster scaffold with the official
Ikemen GO iOS build process.

## Build the IPA without a Mac

1. Create a new GitHub repository.
2. Upload the contents of `Jump_Force_Mugen_New_Starter/` to that repository.
3. Open the repository's **Actions** tab.
4. Select **Build Jump Force Mugen iOS IPA**.
5. Press **Run workflow**.
6. When the workflow finishes, open the workflow run and download the
   `Jump-Force-Mugen-iOS` artifact.
7. The artifact contains `ikemen-go.ipa`.

The workflow uses the official Ikemen GO source and its documented iOS build
command. The generated IPA is unsigned; it must be signed/sideloaded with an
Apple development/sideloading method before installation on an iPhone or iPad.

## Important

This is a new project, not an extracted copy of Jump Force M.U.G.E.N V14.
The roster names and configuration come from the supplied 1,600-slot blueprint.
The character and stage folders are placeholders until real compatible assets
are added.

Do not redistribute copyrighted character, music, sprite, or stage assets
unless you have permission to do so.

# Jump Force Mugen — New 1600-Slot Starter

A new project scaffold based on the uploaded CUSTOM 1,600-SLOT ANIME ROSTER BLUEPRINT.

## Included
- `data/roster.csv` — 1,600 roster slots
- `data/roster_names.txt` — readable roster list
- `data/stages.csv` — 155 stage/map entries
- `data/modes.csv` — 23 listed modes
- `data/select.def` — 1,600 configured roster slots pointing to a temporary placeholder
- `stages/stage_manifest.txt` — stage list
- `chars/Placeholder/` — temporary character scaffold
- `build/build_ios.sh` — macOS helper for the official Ikemen GO iOS build

## Important
This is NOT an extracted copy of Jump Force M.U.G.E.N V14. The uploaded blueprint explicitly says it is not an extracted copy of the original V14 files. Character sprites, animations, sounds, stages and other original game assets are therefore not included.

The 1,600 entries are roster/configuration slots, not 1,600 finished playable characters. Complete M.U.G.E.N/Ikemen character packages (`.def`, `.sff`, `.air`, `.cns`, `.cmd`, `.snd`, etc.) must be added for playable characters.

## iOS
The official Ikemen GO project documents an iOS/iPadOS build that produces an unsigned IPA. Current build requirements include macOS with Xcode 26+ and Go 1.27+.

On a Mac, run:
    ./build/build_ios.sh

The script clones Ikemen GO, copies this project's content into the engine tree, and runs the documented iOS build. The resulting IPA is unsigned and must be signed/sideloaded for installation.


## iOS build

See `BUILD_IPA_WITH_GITHUB.md`. The `.github/workflows/build-ios.yml` workflow builds an unsigned iOS IPA on a macOS GitHub Actions runner.
